const langButton = document.getElementById("languageToggle");
let currentLang = "en";

function setLanguage(lang) {
  currentLang = lang;
  document.body.classList.toggle("gujarati", lang === "gu");
  document.documentElement.lang = lang === "gu" ? "gu" : "en";
  document.querySelectorAll("[data-en][data-gu]").forEach((el) => {
    const value = el.dataset[lang];
    if (value !== undefined) el.innerHTML = value;
  });
  langButton.textContent = lang === "en" ? "ગુજરાતી" : "English";
}
langButton.addEventListener("click", () => setLanguage(currentLang === "en" ? "gu" : "en"));

const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");
menuToggle.addEventListener("click", () => {
  const open = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
});
navLinks.querySelectorAll("a").forEach((link) => link.addEventListener("click", () => {
  navLinks.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
}));

document.getElementById("year").textContent = new Date().getFullYear();
document.getElementById("suggestForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const game = document.getElementById("gameSuggestion").value.trim();
  if (!game) return;
  const subject = encodeURIComponent("Gaming World game suggestion");
  const body = encodeURIComponent("Please consider adding this game to Gaming World: " + game);
  const msg = document.getElementById("formMessage");
  msg.textContent = currentLang === "gu"
    ? "તમારી ઈમેઇલ એપ ખોલવાનો પ્રયાસ થઈ રહ્યો છે. મોકલતા પહેલાં સરનામું ઉમેરો."
    : "Opening your email app. Add the recipient address before sending.";
  window.location.href = `mailto:?subject=${subject}&body=${body}`;
});
