# Gaming World website

A responsive bilingual (English + Gujarati) starter website made with HTML, CSS, and JavaScript.

## Files
- `index.html` — website content
- `style.css` — layout and responsive styling
- `script.js` — language toggle, mobile menu, and game suggestion email draft

## Preview locally
Open `index.html` in a browser. Internet is needed for the optional Google Fonts import; the page still works without it.

## Publish free with GitHub Pages
1. Create or sign in to a GitHub account.
2. Create a **public** repository named `your-username.github.io` (replace with your GitHub username).
3. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
4. In repository **Settings → Pages**, choose deployment from the `main` branch and `/ (root)` if prompted.
5. Wait for the build to finish, then open `https://your-username.github.io`.

## Important notes
- This is a front-end starter template. It has no database, user accounts, upload system, or backend.
- The video section links to YouTube and does not download videos. Only distribute videos you own or have permission to share.
- Monetization is not automatic. Ad networks and affiliate programs have eligibility, policy, and approval requirements.
- Game names and trademarks belong to their respective owners; this fan-made site is not affiliated with them.
